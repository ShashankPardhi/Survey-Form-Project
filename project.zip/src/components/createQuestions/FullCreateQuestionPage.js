import Navbar from './Navbar'
import QuestionTable1 from './QuestionTable1'

function FullCreateQuestionPage() {

    return <>
        <Navbar />
        <QuestionTable1 />
    </>
}

export default FullCreateQuestionPage